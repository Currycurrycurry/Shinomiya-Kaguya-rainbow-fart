# Shinomiya-Kaguya-rainbow-fart
「真是可爱呢（笑）」——《辉夜大小姐想让我告白：天才们的恋爱头脑站》古贺葵/四宫辉夜 vscode-rainbow-fart 扩展语音包 (Shinomiya Kaguya extension vocal pack) Python扩展包
